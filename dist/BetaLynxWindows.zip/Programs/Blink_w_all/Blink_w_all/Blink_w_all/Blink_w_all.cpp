#include "../../../../mainboards/ghi/FEZLynxS4/FEZLynxS4.h"
using namespace GHI;
using namespace GHI::Interfaces;
using namespace GHI::Mainboards;



int main()
{
		FEZLynxS4 board;
		
	for (;;) {
	DigitalOutput(FEZLynxS4::Pins::PA_3,false);
	System::SleepMicro(1*1000*1000);

	DigitalOutput( FEZLynxS4::Pins::PA_3,true);
	System::SleepMicro(1*1000*1000);
	}
	
	

	return 0;

}